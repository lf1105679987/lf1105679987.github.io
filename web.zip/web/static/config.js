var globalConfig = {
  proxy: 'http://47.110.70.236:8010'
}